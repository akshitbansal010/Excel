"""
Tests for excelpy package.
"""
