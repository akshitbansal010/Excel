# DataEngine Pro v2.0

<p align="center">
  <img src="https://img.shields.io/badge/Version-2.0-blue" alt="Version">
  <img src="https://img.shields.io/badge/Python-3.8+-green" alt="Python">
  <img src="https://img.shields.io/badge/License-MIT-yellow" alt="License">
</p>

> **Excel-power. Python speed. DB-connected. Zero BS.**

DataEngine Pro is a powerful command-line data analysis tool that brings Excel-like functionality to Python with SQLite database integration.

## ✨ Features

### 📊 Data View
- **C** - Columns: View all columns with types & samples
- **P** - Preview: Show rows with column picker
- **U** - Unique: See all unique values in a column
- **N** - Null Report: Find missing/empty values
- **S** - Search: Find text anywhere in data
- **I** - Statistics: Numeric summaries (sum, avg, min, max)

### ✏️ Edit & Transform
- **1** - Filter: Keep rows matching criteria (Excel AutoFilter)
- **2** - Add Column: Create new column (formula, IF, map values)
- **3** - Aggregate: Count, Sum, Average by category
- **4** - Sort: Sort by one or more columns
- **5** - Clean Nulls: Fill, delete, or replace missing values
- **6** - Rename/Drop: Rename or delete columns
- **7** - Remove Dupes: Delete duplicate rows
- **9** - Change Type: Convert text↔number↔date

### 🔍 Find & Replace
- **G** - Find & Replace: Like Ctrl+H in Excel
- **F** - Smart Fix: Auto-detect and fix data issues
- **M** - Multi-Filter: Multiple AND/OR conditions

### 📈 Analysis
- **D** - Profile: Full data quality report
- **X** - Outliers: Find unusual values
- **V** - Correlation: How columns relate
- **Q** - Cross-Tab: Frequency table
- **]** - Segment: Group numbers into ranges
- **=** - String Analysis: Text patterns

### 📁 Table Manager
- **T** - Manage: Create, clone, stack, import, delete tables
- **K** - Switch: Change active table

### 💾 Save & Export
- **W** - Save to DB: Save changes to database
- **E** - Export: Export to CSV or Excel

### ↩️ Undo / Reset
- **Z** - Undo: Revert last change
- **R** - Reset: Reset to original data

## 🚀 Installation

### Prerequisites
```bash
# Python 3.8 or higher required
python --version
```

### Install Dependencies
```bash
pip install rich pandas numpy openpyxl rapidfuzz
```

Or let the application auto-install on first run!

## 📖 Usage

### Quick Start
```bash
# Run with an existing database
python dataengine_pro.py

# Specify database directly
python dataengine_pro.py --db my_database.db
```

### Interactive Workflow

1. **Select Database**: Choose from available .db files or enter custom path
2. **Select Table**: Pick a table to work with
3. **Choose Mode**:
   - Mode 1: Create a working copy (recommended)
   - Mode 2: Work directly on loaded data
   - Mode 3: Create a slim table (select specific columns)

4. **Run Commands**: Use single-letter commands from the menu

### Example Session
```
DataEngine ─────────────────────────────────────────────
(sales_work │ 100r × 10c)

→ 1                          # Filter rows
→ C                           # Show columns
→ D                           # Data profile
→ E                           # Export results
→ 0                           # Exit
```

## 🗂️ Project Structure

```
Excel/
├── dataengine_pro.py         # Main entry point
├── test_data.db              # Sample test database
├── data_engine/
│   ├── __init__.py
│   ├── config.py             # Configuration & menus
│   ├── database.py           # SQLite operations
│   ├── display.py            # Rich display functions
│   ├── helpers.py            # Utility functions
│   ├── session.py            # Session management
│   └── operations/           # All operations
│       ├── __init__.py
│       ├── analysis.py       # Data profiling, outliers
│       ├── filter.py         # Filtering operations
│       ├── find_replace.py   # Find & Replace
│       ├── session_io.py     # Save/Export
│       ├── smart_fix.py      # Auto-fix issues
│       ├── table_manager.py  # Table operations
│       ├── transform.py      # Add column, sort, etc.
│       └── view.py           # Preview, search
└── README.md
```

## 🔧 Configuration

### Constants (in `data_engine/config.py`)
- `MAX_UNDO_HISTORY`: 20 - Maximum undo steps
- `DEFAULT_PREVIEW_ROWS`: 8 - Default preview rows
- `LARGE_DATASET_THRESHOLD`: 100000 - Large data handling
- `CHUNK_SIZE`: 10000 - Processing chunk size

## 🐛 Bug Fixes Applied

1. **Division by Zero**: Fixed in outlier detection when DataFrame is empty
2. **Type Conversion**: Fixed crash when entering non-integer for decimal places
3. **Filter Logic**: Fixed boolean mask length mismatch in apply_single_condition
4. **Format String**: Fixed format_number incompatibility with f-string formatting

## ⚠️ Security Notes

When running locally, the following features allow code execution:
- `df.eval()` for formula columns
- `df.query()` for filtering
- User-provided regex patterns

Only use with trusted data in local environments.

## 📝 License

MIT License - Feel free to use and modify!

## 🤝 Contributing

Contributions welcome! Please submit pull requests or open issues for:
- Bug reports
- Feature requests
- Documentation improvements

---

<p align="center">Built with ❤️ using Python & Rich</p>
